/*
===============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/


#include <cr_section_macros.h>
#include "board.h"
#include "chip.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "Board_Config.h"
#include "../app/inc/USD.h"

// TODO: insert other definitions and declarations here
#if defined(BOARD_NXP_LPCXPRESSO_1549)
/* GPIO pin for PININT interrupt.  This is SW1-WAKE button switch input. */
#define TEST_INPUT_PIN          17	/* GPIO pin number mapped to PININT */
#define TEST_INPUT_PORT         0	/* GPIO port number mapped to PININT */
#define TEST_INPUT_PIN_PORT     0
#define TEST_INPUT_PIN_BIT      17
#define PININT_INDEX   1	/* PININT index used for GPIO mapping */
#define PININT_IRQ_HANDLER  PININT1_IRQHandler	/* GPIO interrupt IRQ function name */
#define PININT_NVIC_NAME    PIN_INT1_IRQn	/* GPIO interrupt NVIC interrupt name */

#else
#error "PININT Interrupt not configured for this example"
#endif /* defined(BOARD_NXP_LPCXPRESSO_1549) */

//xSemaphoreHandle userInt_sem;

/* Sets up system hardware */
static inline void prvSetupHardware(void)
{
	SystemCoreClockUpdate();
	Board_Init();

	/* Initial LED0 state is off */
	Board_LED_Set(0, false);
	Board_LED_Set(1, true);

	/* Initialize PININT driver */
	Chip_PININT_Init(LPC_GPIO_PIN_INT);

	/* Set pin back to GPIO (on some boards may have been changed to something
	   else by Board_Init()) */
	Chip_IOCON_PinMuxSet(LPC_IOCON, TEST_INPUT_PIN_PORT, TEST_INPUT_PIN_BIT,
						 (IOCON_DIGMODE_EN | IOCON_MODE_INACT) );

	/* Configure GPIO pin as input */
	Chip_GPIO_SetPinDIRInput(LPC_GPIO, TEST_INPUT_PORT, TEST_INPUT_PIN);

	/* Enable PININT clock */
	Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_PININT);

	/* Reset the PININT block */
	Chip_SYSCTL_PeriphReset(RESET_PININT);

	/* Configure interrupt channel for the GPIO pin in INMUX block */
	Chip_INMUX_PinIntSel(PININT_INDEX, TEST_INPUT_PORT, TEST_INPUT_PIN);

	/* Configure channel interrupt as edge sensitive and falling edge interrupt */
	Chip_PININT_ClearIntStatus(LPC_GPIO_PIN_INT, PININTCH(PININT_INDEX));
	Chip_PININT_SetPinModeEdge(LPC_GPIO_PIN_INT, PININTCH(PININT_INDEX));
	Chip_PININT_EnableIntLow(LPC_GPIO_PIN_INT, PININTCH(PININT_INDEX));

	/* Enable interrupt in the NVIC */
	NVIC_ClearPendingIRQ(PININT_NVIC_NAME);
	NVIC_EnableIRQ(PININT_NVIC_NAME);

}


/* LED1 toggle thread */
static void vLEDTask2() {
	Board_LED_Toggle(1);
}

void PININT_IRQ_HANDLER(void){

	Chip_PININT_ClearIntStatus(LPC_GPIO_PIN_INT, PININTCH(PININT_INDEX));
	vLEDTask2();
}



int main(void) {
	prvSetupHardware();

	vInitUSD_Core();

	/* Should never arrive here */
	return 1;
}
