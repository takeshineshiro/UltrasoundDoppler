/*
 * Board_Config.h
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */

#ifndef BOARD_CONFIG_H_
#define BOARD_CONFIG_H_

#define InterruptPin PIO0_24
#define Enable		 PIO0_27

#define USE_USB			(1)
#define USB_WIN			(1)
#define RTOS			(0)

/*=========================================================================
    USB

    CFG_USB_STRING_MANUFACTURER Manufacturer name that will appear in the
                                device descriptor during USB enumeration
    CFG_USB_STRING_PRODUCT      Product name that will appear in the
                                device descriptor during USB enumeration
    CFG_USB_VENDORID            16-bit USB vendor ID
    USB_PRODUCT_ID              Define this to set a custom product ID
                                if you do not wish to use the 'auto'
                                product ID feature
    CFG_CDC                     Enable USB CDC support
    CFG_USB_HID_KEYBOARD        Enable USB HID keyboard emulation
    CFG_USB_HID_MOUSE           Enable USB HID mouse emulation for a five
                                button 'Windows' mouse with scroll wheels
    CFG_USB_HID_GENERIC         Enable USB HID Generic support for custom
                                in and out reports, with report size set
                                via CFG_USB_HID_GENERIC_REPORT_SIZE
    CFG_USB_MSC                 Enable USB Mass Storage support, pointing
                                to the SD card reader (requires mmc.c from
                                the FATFS drivers, but doesn't use FATFS)


    You can combine more than one USB class below and they will be
    automatically combined in a USB composite device within the limit of
    available USB endpoints.  The USB Product ID is calculated automatically
    based on the combination of classes defined below.

    NOTE: Windows requires the .inf file in '/core/usb' for CDC support
    -----------------------------------------------------------------------*/
#if USE_USB
	#define CFG_ENABLE_USB
#endif
#ifdef CFG_ENABLE_USB
  #define CFG_USB_STRING_MANUFACTURER "HS-Ulm.de"
  #define CFG_USB_STRING_PRODUCT      "Ultrasonic Doppler 2.0"
  #define CFG_USB_VENDORID            (0x1FC9)
  #define CFG_USB_PRODUCTID			  (0xBAAB)
  #define USB_CDC			(0)
  #define USB_HID_KEYBOARD	(0)
  #define USB_HID_MOUSE		(0)
  #define USB_HID_GENERIC	(0)
  #define USB_MSC 			(0)
  #define USB_CUSTOM_CLASS  (1)

  #define USB_BULK_IN		(1)
  #define USB_BULK_OUT		(0)
  #define USB_INT_IN		(0)


#if (USB_CDC)
    #define CFG_USB_CDC
#endif
#if (USB_HID_KEYBOARD)
    #define CFG_USB_HID_KEYBOARD
#endif
#if (USB_HID_MOUSE)
    #define CFG_USB_HID_MOUSE
#endif
#if (USB_HID_GENERIC)
    #define CFG_USB_HID_GENERIC
    #define CFG_USB_HID_GENERIC_REPORT_SIZE (64)
#endif
#if (USB_MSC)
    #define CFG_USB_MSC
#endif
#if (USB_CUSTOM_CLASS)
    #define CFG_USB_CUSTOM_CLASS
  #endif

#if (defined(CFG_USB_CDC)       || defined(CFG_USB_HID_KEYBOARD) || \
     defined(CFG_USB_HID_MOUSE) || defined(CFG_USB_HID_GENERIC)  || \
     defined(CFG_USB_MSC)       || defined(CFG_USB_CUSTOM_CLASS))
  #define CFG_USB
  #if defined(CFG_USB_HID_KEYBOARD) || defined(CFG_USB_HID_MOUSE) || defined(CFG_USB_HID_GENERIC)
    #define CFG_USB_HID
    #if defined(CFG_USB_HID_GENERIC) && (CFG_USB_HID_GENERIC_REPORT_SIZE > 64)
      #error "CFG_USB_HID_GENERIC_REPORT_SIZE exceeds the maximum value of 64 bytes (based on USB specs 2.0 for 'Full Speed Interrupt Endpoint Size')"
    #endif
  #endif
#endif

#endif

#ifdef RTOS
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#endif

#endif /* BOARD_CONFIG_H_ */
