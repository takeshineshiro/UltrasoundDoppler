/*
 * SPI_API.h
 *
 *  Created on: 02.09.2014
 *      Author: Andreas
 */

#ifndef SPI_API_H_
#define SPI_API_H_

#include "chip.h"

typedef struct SPI_API_T* SPI_API_PTR;
struct SPI_API_T{
	ErrorCode_t (*SPI_write16bit)(uint16_t *txbuff, uint32_t transferSize);
	ErrorCode_t (*SPI_transfer16bit)(uint16_t *txbuff, uint16_t *rxbuff, uint32_t transferSize);
	void (*SPI_read)(uint16_t *xferPtr, uint32_t xferSize);
};

SPI_API_PTR SPI_API_CREATE();
void SPI_API_DESTROY(SPI_API_PTR);


#endif /* SPI_API_H_ */
