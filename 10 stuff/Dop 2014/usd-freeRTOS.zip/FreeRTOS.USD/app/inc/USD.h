/*
 * USD.h
 *
 *  Created on: 11.06.2014
 *      Author: Andreas
 */

#ifndef USD_H_
#define USD_H_

#include "USD_core.h"
#ifdef CFG_USB
#include "../USB/inc/common_desc.h"
#endif
#ifdef RTOS
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#endif

void vInitUSD_Core(void);
void vReadUSD_Task(void *params);
xTaskHandle xHandle;

#endif /* USD_H_ */
