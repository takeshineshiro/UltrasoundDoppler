/*
 * SPI_API_config.h
 *
 *  Created on: 02.09.2014
 *      Author: Andreas
 */

#include "USD_core.h"

#ifndef SPI_API_CONFIG_H_
#define SPI_API_CONFIG_H_
#define SPI0 				(1)
#define SPI0_USE_CS			(0)

#define SPI1 				(0)
#define SPI1_USE_CS			(0)

#define DMA 				(1)

#if SPI0
  #define SPI0_DELAY				  \
		  SPI_DLY_PRE_DELAY(0)  	| \
		  SPI_DLY_POST_DELAY(0) 	| \
		  SPI_DLY_FRAME_DELAY(0)	| \
		  SPI_DLY_TRANSFER_DELAY(0)
  #define SPI0_CLK_DEVIDER	1 // frequency = PCLK / (value + 1)
  #define SPI0_CPHA			1
  #define SPI0_CPLO			1

  #define SCK0_PORT			0
  #define SCK0_PIN			5
  #define MOSI0_PORT		0
  #define MOSI0_PIN			6
  #define MISO0_PORT		0
  #define MISO0_PIN			7
  #if SPI0_USE_CS
    #define SSEL0_PORT		0
    #define SSEL0_PIN		8
	#define SSEL0_ACTIVE 	0
  #endif
#endif


#if SPI1
  #define SPI1_DELAY		\
SPI_DLY_PRE_DELAY(0)  	| \
SPI_DLY_POST_DELAY(0) 	| \
SPI_DLY_FRAME_DELAY(0)	| \
SPI_DLY_TRANSFER_DELAY(0)
  #define SPI1_CLK_DEVIDER	1
  #define SPI1_CPHA			1
  #define SPI1_CPLO			1

  #define SCK1_PORT			0
  #define SCK1_PIN			5
  #define MOSI1_PORT		0
  #define MOSI1_PIN			6
  #define MISO1_PORT		0
  #define MISO1_PIN			7
  #if SPI1_USE_CS
    #define SSEL1_PORT		0
    #define SSEL1_PIN		8
	#define SSEL1_ACTIVE 	0
  #endif
#endif

#endif /* SPI_API_CONFIG_H_ */
