/*
 * USD_core.h
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */

#ifndef USD_CORE_H_
#define USD_CORE_H_

#include "chip.h"
#include "../USB/inc/common_desc.h"

#define Samples 512

/* --- USD DATA READY INTERRUPT ---*/
#define USD_DATA_INT_INDEX		0				/* PININT index used for GPIO mapping */
#define USD_DATA_INT_PORT		0				/* GPIO port number mapped to PININT */
#define USD_DATA_INT_PIN		27				/* GPIO pin number mapped to PININT */
#define USD_DATA_INT_NVIC_NAME 	PIN_INT0_IRQn 	/* GPIO interrupt NVIC interrupt name */
#define USD_DATA_IRQ_HANDLER  	PININT0_IRQHandler	/* GPIO interrupt IRQ function name */

/* --- USD CONTROL ENABLE --- */
#define USD_ENABLE_PORT		0					/* GPIO port number mapped to ENABLE */
#define USD_ENABLE_PIN		24					/* GPIO pin number mapped to ENABLE */

typedef enum{
	Set_BURST 		= 0x01,
	Set_ADC 		= 0x02,
	Set_SAMPLE 		= 0x03,
	Set_STOP 		= 0x04,
	Set_RETRANSMIT	= 0x05,
	Set_STATICS 	= 0x06
} Command;

typedef enum{
	Freq2MHz = 0x01,
	Freq4MHz = 0x02,
	Freq8MHz = 0x03,
} Frequency;

typedef enum {
	SetFrequency = 0,
	SetPRF       = 3,
	SetBurst     = 4,
	SetSample    = 5,
	SetDepth     = 6,
	SetDatarate  = 7,
	SetRun       = 8,
	InitScan     = 9,
	NextScan     = 10,
	SetConfiguration = 11
} USB_BEAMSCANNER_REQUEST;

typedef enum {
    USD_MODE_STOP = 0,
    USD_MODE_RUN = 1
} USB_SCANNER_VALUE;

#define CMD_STATICS(freq, mode, run) (freq << 1) | (mode << 3) | (run << 4)

typedef struct {
	uint8_t frequency;
	uint16_t prf;        // puls repetition frequency
	uint16_t burst;      // burst volume [nr of cycles]
	uint16_t sample;     // sample volume [nr of cycles]
	uint16_t depht;      // midlle sample position [mm]
} USD_HW_VALUES;

typedef struct USD_HW_API* USD_HW_API_PTR;
struct USD_HW_API{
	USD_HW_VALUES Settings;
	char Mode;
	void (*WriteFrequency)(void);
	void (*WriteSetupToCtrlFifo)(void);
	void (*Start)(void);
	void (*Stop)(void);
	void (*Scan)(void);
	void (*ReadData)(uint16_t* data, uint16_t size);
	void (*Reset)(void);
};
extern USD_HW_API_PTR usdhandle;

USD_HW_API_PTR USD_HW_API_CREATE(void);
void USD_HW_API_DESTROY(USD_HW_API_PTR);

void SetupHardware(void);

#endif /* USD_CORE_H_ */
