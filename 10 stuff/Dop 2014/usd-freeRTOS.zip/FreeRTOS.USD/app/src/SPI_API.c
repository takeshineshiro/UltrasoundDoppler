/*
 * USD_DataInterface.c
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */
#include <stdlib.h>
#include "SPI_API.h"
#include "SPI_API_config.h"

static SPI_PARAM_T ReadparamRec;
static SPI_PARAM_T Transferparam;
uint16_t txdummy[1] = {0};
static SPI_CONFIG_T spiConfigRec;

#if DMA
static DMA_HANDLE_T dma_handle;	/* handle to DMA */
SPI_PARAM_T param;
DMA_CHANNEL_T chn;
DMA_TASK_T tsk[2];

static volatile bool spiRxAvail;

/**
* @brief	DMA Interrupt Handler
* @return	None
*/
void DMA_IRQHandler(void) {
	/* Call ROM driver handler */
	LPC_DMAD_API->dma_isr(dma_handle);
}
#endif

/* SPI master handle and memory for ROM API */
static SPI_HANDLE_T *SPI0handle;
static uint32_t SPI0handleMEM[0x20]; //0x80 == 128 0x20 == 32

									 /**
									 * @brief	Handle SPI0 interrupt by calling SPI ROM handler
									 * 			not needed for DMA Transfer
									 * @return	Nothing
									 */
void SPI0_IRQHandler(void) {
	/* Call SPI ISR function in ROM with the SPI handle */
	LPC_SPID_API->spi_isr(SPI0handle);
}

static inline void SPI0_pinMux(void) {
	Chip_IOCON_PinMuxSet(LPC_IOCON, SCK0_PORT, SCK0_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, MOSI0_PORT, MOSI0_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, MISO0_PORT, MISO0_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));

	Chip_SWM_MovablePinAssign(SWM_SPI0_SCK_IO, SCK0_PIN);	/* P0.0 */
	Chip_SWM_MovablePinAssign(SWM_SPI0_MOSI_IO, MOSI0_PIN);/* P0.16 */
	Chip_SWM_MovablePinAssign(SWM_SPI0_MISO_IO, MISO0_PIN);/* P0.10 */

#if SPI0_USE_CS
	Chip_IOCON_PinMuxSet(LPC_IOCON, SSEL0_PORT, SSEL0_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));
	Chip_SWM_MovablePinAssign(SWM_SPI0_SSELSN_0_IO, SSEL0_PIN);	/* P0.9 */
#endif
}

static inline void SPI0_init(void) {
	/* Enable SPI clock and reset SPI peripheral - the boot ROM does not do this */
	Chip_SPI_Init(LPC_SPI0);
	SPI0handle = LPC_SPID_API->spi_setup(LPC_SPI0_BASE, (uint8_t *) SPI0handleMEM);

	spiConfigRec.delay = SPI0_DELAY;
	spiConfigRec.divider = SPI0_CLK_DEVIDER;
	/* Loopback mode, master mode and SPI block enabled - refpage 398 */
	spiConfigRec.config = (1 << 0) | //SPI enabled
		(1 << 2) | //Master mode
		(0 << 3) | //LSB First mode (MSB first order.
		(SPI0_CPHA << 4) | //CPHA 1
		(SPI0_CPLO << 5) | //CPLO 1
		(0 << 7) // LOOP mode disabled
#if SPI0_USE_CS
		| (SSEL0_ACTIVE << 8); // SSEL0 low active
#else
		;
#endif
	spiConfigRec.error_en = SPI_STAT_RXOV | SPI_STAT_TXUR;
	LPC_SPID_API->spi_init(SPI0handle, &spiConfigRec); /* Init SPI0 */
	NVIC_EnableIRQ(SPI0_IRQn);	/* Enable SPI0 interrupt */
}


/* private functions */
static ErrorCode_t spi0_write16(uint16_t *txbuff, uint32_t transferSize);
static ErrorCode_t SPI0_transfer16(uint16_t *txbuff, uint16_t *rxbuff, uint32_t transferSize);
static void ReadSpiMssg16(uint16_t *xferPtr, uint32_t xferSize);
static ErrorCode_t spi0_fillTransfer(uint16_t *txbuff, uint32_t transferSize);

static inline void SPI_PinMux(void){
	/* Enable the clock to the Switch Matrix */
	Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_SWM);
	SPI0_pinMux();
	/* Disable the clock to the Switch Matrix to save power */
	Chip_Clock_DisablePeriphClock(SYSCTL_CLOCK_SWM);
}

#if SPI0
static void spi0_receive_callback(ErrorCode_t err_code, uint32_t n) {
 	if(err_code != LPC_OK)
 		LPC_DMAD_API->dma_abort(dma_handle, DMAREQ_SPI0_RX);

 // set the EOT flag in the TXCTL register
 	if (LPC_SPI0->CFG & SPI_MODE_MASTER) LPC_SPI0->TXCTRL |= SPI_TXDATCTL_EOT;
#if DMA
 	Chip_DMA_ClearActiveIntAChannel(LPC_DMA, DMAREQ_SPI0_TX);
 	//TODO
 	spiRxAvail = true;
#endif
}
#endif

#if DMA
static inline void DMA_init(void){
	Chip_DMA_Init(LPC_DMA);
	/*info{LPC_DMA_BASE := (uint32_t)LPC_DMA}*/
	dma_handle = LPC_DMAD_API->dma_setup(LPC_DMA_BASE, (uint8_t*)DMA_ADDR(Chip_DMA_Table));
	NVIC_EnableIRQ(DMA_IRQn);

	chn.event = DMA_ROM_CH_EVENT_PERIPH;
	chn.hd_trigger = DMA_ROM_CH_HWTRIG_BURSTPOWER_1; // no hardware trigger -> 0
	chn.priority = 3;
#if SPI0
	chn.cb_func = (CALLBK_T) spi0_receive_callback;// callback for transfer done. page reference 637 / section 40.4.8.5
	tsk[0].src 			= DMA_ADDR(&LPC_SPI0->RXDAT); /* Byte aligned */
	tsk[1].dst 			= DMA_ADDR(&LPC_SPI0->TXDAT); /* Byte aligned */
#endif
	//receiver task
	tsk[0].ch_num 		= DMAREQ_SPI0_RX;
	tsk[0].config 		= DMA_ROM_TASK_CFG_SEL_INTA | DMA_ROM_TASK_CFG_SW_TRIGGER;
	tsk[0].data_type	= DMA_ROM_TASK_DATA_WIDTH_16 | DMA_ROM_TASK_SRC_INC_0 | DMA_ROM_TASK_DEST_INC_1;
	//attention on DMA_ROM_TASK_DATA_WIDTH_X -> need to be the width of the buffer.. this costs me 2 days
	tsk[0].data_length 	= Samples - 1;
	tsk[0].task_addr 	= (uint32_t) &tsk[0]; // for task head, no memory is needed -> only for pingpong or linked list else write only to registers
	//transmitter task
	tsk[1].ch_num 		= DMAREQ_SPI0_TX;
	tsk[1].config 		= DMA_ROM_TASK_CFG_SEL_INTA | DMA_ROM_TASK_CFG_SW_TRIGGER;
	tsk[1].data_type 	= DMA_ROM_TASK_DATA_WIDTH_16 | DMA_ROM_TASK_SRC_INC_0 | DMA_ROM_TASK_DEST_INC_0;
	//attention on DMA_ROM_TASK_DATA_WIDTH_X -> need to be the width of the buffer.. this costs me 2 days
	tsk[1].data_length 	= Samples - 1;
	tsk[1].src 			= DMA_ADDR(&txdummy[0] + tsk[1].data_length); //pointer to param.tx_buffer brings nothing.. need the real address
	tsk[1].task_addr 	= (uint32_t) &tsk[1]; // for task head, no memory is needed -> only for pingpong or linked list else write only to registers
}

//Define the DMA receive callback function
static ErrorCode_t dma_transfer_callback(SPI_HANDLE_T handle, SPI_DMA_CFG_T *dma_cfg) {
	ErrorCode_t error_code = LPC_DMAD_API->dma_init(dma_handle, &chn, &tsk[0]);
	if(error_code != LPC_OK) return error_code;
	error_code = LPC_DMAD_API->dma_init(dma_handle, &chn, &tsk[1]);
	return error_code;
}

#endif

/* public functions */

SPI_API_PTR  SPI_API_CREATE(void) {
	SPI_API_PTR instance = (SPI_API_PTR) malloc(sizeof(struct SPI_API_T));
	SPI_PinMux();
	SPI0_init();
#if DMA
	DMA_init();
	ReadparamRec.driver_mode = 0x02; // DMA mode
	ReadparamRec.dma_cb = (SPI_DMA_REQ_T) dma_transfer_callback;
	//TODO:
	chn.event = DMA_ROM_CH_EVENT_PERIPH;
	chn.hd_trigger = DMA_ROM_CH_HWTRIG_BURSTPOWER_1; // no hardware trigger -> 0
	chn.priority = 3;
#else
	ReadparamRec.driver_mode = 0x01; // Interrupt mode
#endif
	instance->SPI_write16bit = spi0_write16;
	instance->SPI_transfer16bit = SPI0_transfer16;
	instance->SPI_read = ReadSpiMssg16;

	/* Setup transfer record */
	ReadparamRec.tx_buffer = txdummy;	/* SPI TX buffer */ // 252 / 126
	ReadparamRec.size = Samples;		/* total number of SPI transfers */
	ReadparamRec.fsize_sel = 0x0F0E0000; //SPI_TXDATCTL_ASSERT_SSEL0 | SPI_TXDATCTL_LEN(16);
	ReadparamRec.tx_rx_flag = 0x02; // TX AND RX needed to generate clock..
	ReadparamRec.eof_flag = 0;
	ReadparamRec.cb = (SPI_CALLBK_T) spi0_receive_callback;

	Transferparam.fsize_sel = 0xF0E0000;/* Set Tx Control for 16 bit transfer, SSEL0 asserted */
	Transferparam.eof_flag = 0;	/* End of Frame enabled */
	Transferparam.driver_mode = 0;		/* polling mode */
	Transferparam.dma_cfg = NULL;		/* DMA configuration */
	Transferparam.cb = NULL;			/* SPI completion callback */
	Transferparam.dma_cb = NULL;		/* DMA completion callback */
	return instance;
}

void SPI_API_DESTROY(SPI_API_PTR instance) {
	free(instance);
}

static inline ErrorCode_t spi0_fillTransfer(uint16_t *txbuff, uint32_t transferSize){
	Transferparam.tx_buffer = txbuff;	/* SPI TX buffer */
	Transferparam.size = transferSize;	/* total number of SPI transfers */
	/* Transfer message as SPI master via polling */
	return LPC_SPID_API->spi_master_transfer(SPI0handle, &Transferparam);
}

/* Master SPI transmit in polling mode */
static ErrorCode_t spi0_write16(uint16_t *txbuff, uint32_t transferSize){
	/* Setup transfer record */
	Transferparam.rx_buffer = NULL;	/* SPI RX buffer */
	Transferparam.tx_rx_flag = 0;		/* transmit */
	return spi0_fillTransfer(txbuff, transferSize);
}

static ErrorCode_t SPI0_transfer16(uint16_t *txbuff, uint16_t *rxbuff, uint32_t transferSize){
	/* Setup transfer record */
	Transferparam.rx_buffer = rxbuff;	/* SPI RX buffer */	
	Transferparam.tx_rx_flag = 2;		/* transmit and receive */
	return spi0_fillTransfer(txbuff, transferSize);
}

static void ReadSpiMssg16(uint16_t *xferPtr, uint32_t xferSize){
#if DMA
	tsk[0].dst 			= DMA_ADDR(&xferPtr[0] + tsk[0].data_length); //pointer to param.rx_buffer brings nothing.. need the real address
#else
	ReadparamRec.rx_buffer = xferPtr;	/* SPI RX buffer */
#endif
	/* Transfer message as SPI master via interrupt */
	LPC_SPID_API->spi_master_transfer(SPI0handle, &ReadparamRec);
}
