#include "USD_core.h"
#include "SPI_API.h"
#include <stdlib.h>


enum SCANNERINITVALUES{
    INITVAL_FREQ_MHZ    = Freq8MHz,
    INITVAL_PRF         = 64000000/10000-1, // 10kHz
    INITVAL_BURST       = 160,  // 10/4 *64
    INITVAL_SAMPLE      = 1024,  // 14/4 *64
    INITVAL_DEPHT       = 1044  //
};

SPI_API_PTR spiHandle;

void SetupHardware(void){
	/* Initialize PININT driver */
	//Chip_PININT_Init(LPC_GPIO_PIN_INT);

	/* Set pin back to GPIO (on some boards may have been changed to something
	   else by Board_Init()) */
	Chip_IOCON_PinMuxSet(LPC_IOCON, USD_DATA_INT_PORT, USD_DATA_INT_PIN,
						 (IOCON_DIGMODE_EN | IOCON_MODE_INACT) );

	/* Configure GPIO pin as input */
	Chip_GPIO_SetPinDIRInput(LPC_GPIO, USD_DATA_INT_PORT, USD_DATA_INT_PIN);

	/* Enable PININT clock */
	//Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_PININT);

	/* Reset the PININT block */
	//Chip_SYSCTL_PeriphReset(RESET_PININT);

	/* Configure interrupt channel for the GPIO pin in INMUX block */
	//Chip_INMUX_PinIntSel(USD_DATA_INT_INDEX, USD_DATA_INT_PORT, USD_DATA_INT_PIN);

	/* Configure channel interrupt as edge sensitive and falling edge interrupt */
	//Chip_PININT_ClearIntStatus(LPC_GPIO_PIN_INT, PININTCH(USD_DATA_INT_INDEX));
	//Chip_PININT_SetPinModeEdge(LPC_GPIO_PIN_INT, PININTCH(USD_DATA_INT_INDEX));
	//Chip_PININT_EnableIntHigh(LPC_GPIO_PIN_INT, PININTCH(USD_DATA_INT_INDEX));

	/* Enable interrupt in the NVIC */
	//NVIC_ClearPendingIRQ(USD_DATA_INT_NVIC_NAME);
	//NVIC_EnableIRQ(USD_DATA_INT_NVIC_NAME);

/* --- SPI --- */
	spiHandle = SPI_API_CREATE();
/* --- ENABLE --- */
	Chip_GPIO_SetPinDIROutput(LPC_GPIO, USD_ENABLE_PORT, USD_ENABLE_PIN);
	Chip_GPIO_SetPinState(LPC_GPIO, USD_ENABLE_PORT, USD_ENABLE_PIN, false);
	Chip_GPIO_SetPinState(LPC_GPIO, USD_ENABLE_PORT, USD_ENABLE_PIN, true);
}

static void HAL_Reset(void);
static void HAL_WriteFrequency(void);
static void HAL_WriteSetupToCtrlFifo(void);
static void HAL_ScannerStart(void);
static void HAL_ScannerStop(void);
static void HAL_SCAN(void);
void HAL_ReadData(uint16_t* data, uint16_t size);


static void USD_HW_API_Implementation(USD_HW_API_PTR instance){
	instance->Settings.frequency = INITVAL_FREQ_MHZ;  // init scanner configuration
	instance->Settings.prf = INITVAL_PRF;
	instance->Settings.burst = INITVAL_BURST;
	instance->Settings.sample = INITVAL_SAMPLE;
	instance->Settings.depht = INITVAL_DEPHT;
	instance->Mode = 0;
	instance->WriteFrequency = HAL_WriteFrequency;
	instance->WriteSetupToCtrlFifo = HAL_WriteSetupToCtrlFifo;
	instance->Start = HAL_ScannerStart;
	instance->Stop = HAL_ScannerStop;
	instance->Scan = HAL_SCAN;
	instance->Reset = HAL_Reset;
	instance->ReadData = HAL_ReadData;
}

USD_HW_API_PTR USD_HW_API_CREATE(void){
	USD_HW_API_PTR instance = (USD_HW_API_PTR)malloc(sizeof(struct USD_HW_API));
	SetupHardware();
	USD_HW_API_Implementation(instance);
	return instance;
}

void USD_HW_API_DESTROY(USD_HW_API_PTR instance){
	free(instance);
}

static void HAL_Reset(void){

	uint16_t cmd[] = {
		(Set_STATICS << 0), (1 << 0),
		(Set_STATICS << 0), CMD_STATICS(usdhandle->Settings.frequency, 0 , 0)
	};
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
}

static void HAL_WriteFrequency(void){
	uint16_t cmd[] = {
				(Set_STATICS << 0), CMD_STATICS(usdhandle->Settings.frequency, 0 , 0)
		};
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
}

static void HAL_WriteSetupToCtrlFifo(void){
	uint16_t cmd[] = {
			(Set_STATICS << 0), (1 << 0),
			Set_BURST, usdhandle->Settings.burst,
			Set_ADC, usdhandle->Settings.sample-9,
			Set_SAMPLE, usdhandle->Settings.sample,
			Set_STOP, usdhandle->Settings.depht,
			Set_RETRANSMIT, usdhandle->Settings.prf,
			(Set_STATICS << 0), CMD_STATICS(usdhandle->Settings.frequency, 0 , 0)
	};
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
}



static void HAL_ScannerStart(void){
	uint16_t cmd[] = {
		(Set_STATICS << 0),CMD_STATICS(usdhandle->Settings.frequency, 1 , 1)
	};
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
}

static void HAL_ScannerStop(void){
	uint16_t cmd[] = {
		(Set_STATICS << 0), CMD_STATICS(usdhandle->Settings.frequency, 0 , 0)
	};
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
}

static void HAL_SCAN(void){
	uint16_t cmd[] = {
		(Set_STATICS << 0), CMD_STATICS(usdhandle->Settings.frequency, 0 , 1)
		};
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
	spiHandle->SPI_write16bit(cmd, sizeof(cmd) / sizeof(cmd[0]));
}

inline void HAL_ReadData(uint16_t* data, uint16_t size){
	spiHandle->SPI_read(data, size);
}
