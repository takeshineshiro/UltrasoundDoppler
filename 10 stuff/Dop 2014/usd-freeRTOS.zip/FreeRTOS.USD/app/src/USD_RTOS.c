/*
 * USD_RTOS.c
 *
 *  Created on: 11.06.2014
 *      Author: Andreas
 */

#include "USD.h"
#ifdef RTOS
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#endif

xSemaphoreHandle usd_Read_Semaphore;

USD_HW_API_PTR usdhandle;

static uint8_t g_rxBuff[2][Samples*2] = {{0},{0}};
static uint16_t buffSize = Samples;//sizeof(g_rxBuff) / sizeof(g_rxBuff[0]);
int32_t ret, i, j, prompt;


void vInitUSD_Core(void){

#ifdef CFG_USB
	// init usb interface
	dev_init(0x02008000, 0x1000);


#endif
	// Create USD handle
	usdhandle = USD_HW_API_CREATE();
	usdhandle->Reset();
	usdhandle->WriteSetupToCtrlFifo();

i = Samples;
j = 0;
/* 8,62 ms für usb + SPI
 * 1,52 ms für SPI
 * = 5,6 SPI Transfers ...
 * bei 2,5 ms für prf daten ->
 * */
		while(1){
			if(dev_Connected() && (g_lusb.tx_flags & TX_BUSY) == 0){
				i = i + dev_QueueSendReq(&g_rxBuff[(j == 0) ? 1 : 0][i], USB_FS_MAX_BULK_PACKET*8);
				if(i >= Samples){
					i = 0;
					j = (j == 0) ? 1 : 0;
					if(Chip_GPIO_GetPinState(LPC_GPIO,USD_DATA_INT_PORT,USD_DATA_INT_PIN))
						usdhandle->ReadData((uint16_t*)&g_rxBuff[j][0], Samples);
				}
			}
		}
}

void PerformUSB_Vendor(int8_t cmd, uint16_t value){
	switch(cmd){
		case SetFrequency:
			usdhandle->Settings.frequency = value;
			break;
		case SetPRF:
			usdhandle->Settings.prf = value;
			break;
		case SetBurst:
			usdhandle->Settings.burst = value;
			break;
		case SetSample:
			usdhandle->Settings.sample = value;
			break;
		case SetDepth: usdhandle->Settings.depht = value; break;
		case SetRun:
			if(value == USD_MODE_RUN){
				usdhandle->Start();
				usdhandle->Mode = 1;
				Board_LED_Toggle(2);
			}
			else {
				usdhandle->Stop();
				usdhandle->Mode = 0;
			}
			break;
		case SetConfiguration:
			usdhandle->Reset();
			usdhandle->WriteSetupToCtrlFifo();
			break;
		case InitScan:
			usdhandle->Scan();
			break;
		case NextScan:
			break;
		default:
			break;
	} //end switch
}
