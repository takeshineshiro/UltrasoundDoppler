/*
* USD_DataInterface.c
*
*  Created on: 10.06.2014
*      Author: Andreas
*/
#include <stdlib.h>
#include "SPI_API.h"
#include "USD_core.h"

#if DMA
static DMA_HANDLE_T dma_handle;	/* handle to DMA */
SPI_PARAM_T param;
DMA_CHANNEL_T chn;
DMA_TASK_T tsk[2];

static volatile bool spiRxAvail;
#endif

static SPI_PARAM_T ReadparamRec;
uint16_t txdummy[Samples] = { 0 };
static SPI_CONFIG_T spiConfigRec;

/* IRQs*/
#if DMA
/**
* @brief	DMA Interrupt Handler
* @return	None
*/
void DMA_IRQHandler(void) {
	/* Call ROM driver handler */
	LPC_DMAD_API->dma_isr(dma_handle);
}
#endif

/* SPI master handle and memory for ROM API */
static SPI_HANDLE_T *SPI1handle;
static uint32_t SPI1handleMEM[0x20]; //0x80 == 128 0x20 == 32

									 /**
									 * @brief	Handle SPI1 interrupt by calling SPI ROM handler
									 * 			not needed for DMA Transfer
									 * @return	Nothing
									 */
void SPI1_IRQHandler(void) {
	/* Call SPI ISR function in ROM with the SPI handle */
	LPC_SPID_API->spi_isr(SPI1handle);
}

static void SPI1_pinMux(void) {
	Chip_IOCON_PinMuxSet(LPC_IOCON, SCK1_PORT, SCK1_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, MOSI1_PORT, MOSI1_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, MISO1_PORT, MISO1_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));
#if SPI1_USE_CS
	Chip_IOCON_PinMuxSet(LPC_IOCON, SSEL1_PORT, SSEL1_PIN, (IOCON_MODE_INACT | IOCON_DIGMODE_EN));
#endif

static void SPI1_init(void) {
	/* Enable SPI clock and reset SPI peripheral - the boot ROM does not do this */
	Chip_SPI_Init(LPC_SPI1);
	SPI1handle = LPC_SPID_API->spi_setup(LPC_SPI1_BASE, (uint8_t *) SPI1handleMEM);

	/* Setup SPI0 configuration record */
	spiConfigRec.delay = SPI1_DELAY;
	/* SysClock divided is set to maximum */
	spiConfigRec.divider = SPI1_CLK_DEVIDER; //frequency PCLK/(Value+1) pageref 407 - section 25.6.10
											 /* Loopback mode, master mode and SPI block enabled - refpage 398 */
	spiConfigRec.config = (1 << 0) | //SPI enabled
		(1 << 2) | //Master mode
		(0 << 3) | //LSB First mode (MSB first order.
		(SPI1_CPHA << 4) | //CPHA 1
		(SPI1_CPLO << 5) | //CPLO 1
		(0 << 7)   // LOOP mode disabled
#if SPI1_USE_CS
		| (SSEL1_ACTIVE << 8); // SSEL0 low active
#else
		;
#endif
	spiConfigRec.error_en = SPI_STAT_RXOV | SPI_STAT_TXUR;

	/* Init SPI1 */
	LPC_SPID_API->spi_init(SPI1handle, &spiConfigRec);

	/* Enable SPI0 interrupt */
	NVIC_EnableIRQ(SPI1_IRQn);
}
#endif


/* private functions */

static inline void SPI_PinMux(void) {
	/* Enable the clock to the Switch Matrix */
	Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_SWM);
	SPI1_pinMux();
	/* Disable the clock to the Switch Matrix to save power */
	Chip_Clock_DisablePeriphClock(SYSCTL_CLOCK_SWM);
}


#if DMA
static void DMA_init(void) {
	Chip_DMA_Init(LPC_DMA);
	/*info{LPC_DMA_BASE := (uint32_t)LPC_DMA}*/
	dma_handle = LPC_DMAD_API->dma_setup(LPC_DMA_BASE, (uint8_t*) DMA_ADDR(Chip_DMA_Table));
	NVIC_EnableIRQ(DMA_IRQn);

	chn.event = DMA_ROM_CH_EVENT_PERIPH;
	chn.hd_trigger = DMA_ROM_CH_HWTRIG_BURSTPOWER_1; // no hardware trigger -> 0
	chn.priority = 3;
#if SPI0
	chn.cb_func = (CALLBK_T) spi0_receive_callback;// callback for transfer done. page reference 637 / section 40.4.8.5
	tsk[0].src = DMA_ADDR(&LPC_SPI0->RXDAT); /* Byte aligned */
	tsk[1].dst = DMA_ADDR(&LPC_SPI0->TXDAT); /* Byte aligned */
#endif
											 //receiver task
	tsk[0].ch_num = DMAREQ_SPI0_RX;
	tsk[0].config = DMA_ROM_TASK_CFG_SEL_INTA | DMA_ROM_TASK_CFG_SW_TRIGGER;
	tsk[0].data_type = DMA_ROM_TASK_DATA_WIDTH_16 | DMA_ROM_TASK_SRC_INC_0 | DMA_ROM_TASK_DEST_INC_1;
	//attention on DMA_ROM_TASK_DATA_WIDTH_X -> need to be the width of the buffer.. this costs me 2 days
	tsk[0].data_length = Samples - 1;
	tsk[0].task_addr = (uint32_t) &tsk[0]; // for task head, no memory is needed -> only for pingpong or linked list else write only to registers
										   //transmitter task
	tsk[1].ch_num = DMAREQ_SPI0_TX;
	tsk[1].config = DMA_ROM_TASK_CFG_SEL_INTA | DMA_ROM_TASK_CFG_SW_TRIGGER;
	tsk[1].data_type = DMA_ROM_TASK_DATA_WIDTH_16 | DMA_ROM_TASK_SRC_INC_1 | DMA_ROM_TASK_DEST_INC_0;
	//attention on DMA_ROM_TASK_DATA_WIDTH_X -> need to be the width of the buffer.. this costs me 2 days
	tsk[1].data_length = Samples - 1;
	tsk[1].src = DMA_ADDR(&txdummy[0] + tsk[1].data_length); //pointer to param.tx_buffer brings nothing.. need the real address
	tsk[1].task_addr = (uint32_t) &tsk[1]; // for task head, no memory is needed -> only for pingpong or linked list else write only to registers
}

//Define the DMA receive callback function
static ErrorCode_t dma_transfer_callback(SPI_HANDLE_T handle, SPI_DMA_CFG_T *dma_cfg) {
	ErrorCode_t error_code = LPC_DMAD_API->dma_init(dma_handle, &chn, &tsk[0]);
	if (error_code != LPC_OK) return error_code;
	error_code = LPC_DMAD_API->dma_init(dma_handle, &chn, &tsk[1]);
	return error_code;
}

#endif

static void Setup(void) {
	SPI_PinMux();

	SPI1_init();
#if DMA
	DMA_init();
#endif
}


/* public functions */

SPI_API_PTR SPI_API_CREATE(void) {
	SPI_API_PTR instance = (SPI_API_PTR) malloc(sizeof(struct SPI_API_T));
	Setup();
#endif

#if DMA
	//TODO:
	chn.event = DMA_ROM_CH_EVENT_PERIPH;
	chn.hd_trigger = DMA_ROM_CH_HWTRIG_BURSTPOWER_1; // no hardware trigger -> 0
	chn.priority = 3;
#endif

#if SPI1

#endif
	return instance;
}

void SPI_API_DESTROY(SPI_API_PTR instance) {
	free(instance);
}
