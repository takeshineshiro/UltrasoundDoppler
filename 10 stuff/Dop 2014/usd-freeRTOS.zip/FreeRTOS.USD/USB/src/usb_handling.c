/*
 * usb_handling.c
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */

/*
 * usb_api.c
 *
 *  Created on: 09.05.2014
 *      Author: Andreas
 */

#include <stdio.h>
#include <string.h>

#include "chip.h"
#include "app_usbd_cfg.h"
#include "WinUSB_desc.h"
#include "common_desc.h"
#include "usbd/usbd_rom_api.h"

#include "USD_core.h"

LUSB_CTRL_T g_lusb;

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/
const USBD_API_T *g_pUsbApi;

/**
 * USB Device Qualifier
 */
ALIGNED(4) const uint8_t USB_DeviceQualifier[] = {
	USB_DEVICE_QUALI_SIZE,					/* bLength */
	USB_DEVICE_QUALIFIER_DESCRIPTOR_TYPE,	/* bDescriptorType */
	WBVAL(0x0200),							/* bcdUSB: 2.00 */
	0xff,									/* bDeviceClass */
	0x00,									/* bDeviceSubClass */
	0x00,									/* bDeviceProtocol */
	USB_MAX_PACKET0,						/* bMaxPacketSize0 */
	0x01,									/* bNumOtherSpeedConfigurations */
	0x00									/* bReserved */
};

/* USB FSConfiguration Descriptor */
/*   All Descriptors (Configuration, Interface, Endpoint, Class, Vendor */
ALIGNED(4) const USB_FS_CONFIGURATION_DESCRIPTOR USB_FsConfigDescriptor ={
	.Config = {
		.bLength             = USB_CONFIGURATION_DESC_SIZE,
		.bDescriptorType     = USB_CONFIGURATION_DESCRIPTOR_TYPE,
		.wTotalLength        = sizeof(USB_FS_CONFIGURATION_DESCRIPTOR) - 1, // exclude termination
		.bNumInterfaces      = TOTAL_INTEFACES,

		.bConfigurationValue = 1,
		.iConfiguration      = 0x00,
		.bmAttributes        = USB_CONFIG_BUS_POWERED,
		.bMaxPower           = USB_CONFIG_POWER_MA(400)
	},
	#if IAD_DESC_REQUIRED
    // IAD points to CDC Interfaces
    .CDC_IAD = {
        .bLength           = sizeof(USB_IAD_DESCRIPTOR),
        .bDescriptorType   = USB_INTERFACE_ASSOCIATION_DESCRIPTOR_TYPE,

        .bFirstInterface   = 0,
        .bInterfaceCount   = 2,

        .bFunctionClass    = CDC_COMMUNICATION_INTERFACE_CLASS,
        .bFunctionSubClass = CDC_ABSTRACT_CONTROL_MODEL,
        .bFunctionProtocol = CDC_PROTOCOL_COMMON_AT_COMMANDS,

        .iFunction         = 0
    },
    #endif

	#ifdef CFG_USB_CDC
    // USB CDC Serial Interface
    // CDC Control Interface
    .CDC_CCI_Interface =
    {
        .bLength            = sizeof(USB_INTERFACE_DESCRIPTOR),
        .bDescriptorType    = USB_INTERFACE_DESCRIPTOR_TYPE,
        .bInterfaceNumber   = INTERFACE_INDEX_CDC,
        .bAlternateSetting  = 0,
        .bNumEndpoints      = 1,
        .bInterfaceClass    = CDC_COMMUNICATION_INTERFACE_CLASS,
        .bInterfaceSubClass = CDC_ABSTRACT_CONTROL_MODEL,
        .bInterfaceProtocol = CDC_PROTOCOL_COMMON_AT_COMMANDS,
        .iInterface         = 0x00
    },

    .CDC_Header =
    {
        .bFunctionLength    = sizeof(CDC_HEADER_DESCRIPTOR),
        .bDescriptorType    = CDC_CS_INTERFACE,
        .bDescriptorSubtype = CDC_HEADER,
        .bcdCDC             = 0x0120
    },

    .CDC_ACM =
    {
        .bFunctionLength    = sizeof(CDC_ABSTRACT_CONTROL_MANAGEMENT_DESCRIPTOR),
        .bDescriptorType    = CDC_CS_INTERFACE,
        .bDescriptorSubtype = CDC_ABSTRACT_CONTROL_MANAGEMENT,
        .bmCapabilities     = 0x06 // Support Send_Break and Set_Line_Coding, Set_Control_Line_State, Get_Line_Coding, and the notification Serial_State
    },

    .CDC_Union =
    {
        .sUnion =
        {
            .bFunctionLength    = sizeof(CDC_UNION_1SLAVE_DESCRIPTOR),
            .bDescriptorType    = CDC_CS_INTERFACE,
            .bDescriptorSubtype = CDC_UNION,
            .bMasterInterface   = 0
        },
        .bSlaveInterfaces[0] = 1
    },

    .CDC_NotificationEndpoint =
    {
        .bLength          = sizeof(USB_ENDPOINT_DESCRIPTOR),
        .bDescriptorType  = USB_ENDPOINT_DESCRIPTOR_TYPE,
        .bEndpointAddress = CDC_NOTIFICATION_EP,
        .bmAttributes     = USB_ENDPOINT_TYPE_INTERRUPT,
        .wMaxPacketSize   = CDC_NOTIFICATION_EP_MAXPACKETSIZE,
        .bInterval        = 0xff // lowest polling rate
    },

    // CDC Data Interface
    .CDC_DCI_Interface =
    {
        .bLength            = sizeof(USB_INTERFACE_DESCRIPTOR),
        .bDescriptorType    = USB_INTERFACE_DESCRIPTOR_TYPE,
        .bInterfaceNumber   = INTERFACE_INDEX_CDC+1,
        .bAlternateSetting  = 0x00,
        .bNumEndpoints      = 2,
        .bInterfaceClass    = CDC_DATA_INTERFACE_CLASS,
        .bInterfaceSubClass = 0,
        .bInterfaceProtocol = 0,
        .iInterface         = 0x00
    },

    .CDC_DataOutEndpoint =
    {
        .bLength          = sizeof(USB_ENDPOINT_DESCRIPTOR),
        .bDescriptorType  = USB_ENDPOINT_DESCRIPTOR_TYPE,
        .bEndpointAddress = CDC_DATA_EP_OUT,
        .bmAttributes     = USB_ENDPOINT_TYPE_BULK,
        .wMaxPacketSize   = CDC_DATA_EP_MAXPACKET_SIZE,
        .bInterval        = 0
    },

    .CDC_DataInEndpoint =
    {
        .bLength          = sizeof(USB_ENDPOINT_DESCRIPTOR),
        .bDescriptorType  = USB_ENDPOINT_DESCRIPTOR_TYPE,
        .bEndpointAddress = CDC_DATA_EP_IN,
        .bmAttributes     = USB_ENDPOINT_TYPE_BULK,
        .wMaxPacketSize   = CDC_DATA_EP_MAXPACKET_SIZE,
        .bInterval        = 0
    },
    #endif

    #ifdef CFG_USB_CUSTOM_CLASS
    .Custom_Interface = {
        .bLength            = USB_INTERFACE_DESC_SIZE,
        .bDescriptorType    = USB_INTERFACE_DESCRIPTOR_TYPE,
        .bInterfaceNumber   = INTERFACE_INDEX_CUSTOM,
        .bAlternateSetting  = 0x00,
        .bNumEndpoints      = (USB_BULK_IN + USB_BULK_OUT + USB_INT_IN),
        .bInterfaceClass    = USB_DEVICE_CLASS_VENDOR_SPECIFIC,
        .bInterfaceSubClass = 0xf0,
        .bInterfaceProtocol = 0x00,
        .iInterface         = 0x04
    },
	#if USB_BULK_IN
    .Custom_BulkIN = {
        .bLength          = USB_ENDPOINT_DESC_SIZE,
        .bDescriptorType  = USB_ENDPOINT_DESCRIPTOR_TYPE,
        .bEndpointAddress = LUSB_IN_EP,
        .bmAttributes     = USB_ENDPOINT_TYPE_BULK,
        .wMaxPacketSize   = 64,
        //.bInterval		  = 0,
    },
	#endif
	#if USB_BULK_OUT
    .Custom_BulkOUT = {
        .bLength          = USB_ENDPOINT_DESC_SIZE,
        .bDescriptorType  = USB_ENDPOINT_DESCRIPTOR_TYPE,
        .bEndpointAddress = LUSB_OUT_EP,
        .bmAttributes     = USB_ENDPOINT_TYPE_BULK,
        .wMaxPacketSize   = USB_FS_MAX_BULK_PACKET,
    },
	#endif
	#if USB_INT_IN
    .HID_GenericINEndpoint = {
		.bLength          = USB_ENDPOINT_DESC_SIZE,
		.bDescriptorType  = USB_ENDPOINT_DESCRIPTOR_TYPE,
		.bEndpointAddress = LUSB_INT_EP,
		.bmAttributes     = USB_ENDPOINT_TYPE_INTERRUPT,
		.wMaxPacketSize   = 4,
		.bInterval		  = 0x8,
    },
    #endif
	#endif
    .ConfigDescTermination = 0,
};



ALIGNED(4) const uint8_t USB_StringDescriptor[] = {
	/* Index 0x00: LANGID Codes */
	0x04,							/* bLength */
	USB_STRING_DESCRIPTOR_TYPE,		/* bDescriptorType */
	WBVAL(0x0409),					/* wLANGID  0x0409 = US English*/
	/* Index 0x01: Manufacturer */
	(9 * 2 + 2),					/* bLength (18 Char + Type + length) */
	USB_STRING_DESCRIPTOR_TYPE,		/* bDescriptorType */
	'H', 0,
	'S', 0,
	'-', 0,
	'U', 0,
	'l', 0,
	'm', 0,
	'.', 0,
	'd', 0,
	'e', 0,

	/* Index 0x02: Product */
	(18 * 2 + 2),					/* bLength (19 Char + Type + length) */
	USB_STRING_DESCRIPTOR_TYPE,		/* bDescriptorType */
	'U', 0,
	'l', 0,
	't', 0,
	'r', 0,
	'a', 0,
	's', 0,
	'o', 0,
	'n', 0,
	'i', 0,
	'c', 0,
	' ', 0,
	'D', 0,
	'o', 0,
	'p', 0,
	'p', 0,
	'l', 0,
	'e', 0,
	'r', 0,
	/* Index 0x03: Serial Number */
	(12 * 2 + 2),					/* bLength (13 Char + Type + length) */
	USB_STRING_DESCRIPTOR_TYPE,		/* bDescriptorType */
	'I', 0,
	'M', 0,
	'M', 0,
	':', 0,
	'2', 0,
	'0', 0,
	'1', 0,
	'4', 0,
	'-', 0,
	'0', 0,
	'2', 0,
	'4', 0,
	/* Index 0x04: Interface 0, Alternate Setting 0 */
	(6 * 2 + 2),					/* bLength (6 Char + Type + length) */
	USB_STRING_DESCRIPTOR_TYPE,		/* bDescriptorType */
	'S', 0,
	't', 0,
	'r', 0,
	'e', 0,
	'a', 0,
	'm', 0,
};

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/* Handle USB RESET event */
ErrorCode_t ResetEvent(USBD_HANDLE_T hUsb){
	/* reset the control structure */
	memset(&g_lusb, 0, sizeof(LUSB_CTRL_T));
	g_lusb.hUsb = hUsb;
	return LPC_OK;
}


/* USB bulk EP_IN endpoint handler */
ErrorCode_t BulkIN_Hdlr(USBD_HANDLE_T hUsb, void *data, uint32_t event){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) data;
	if (event == USB_EVT_IN) {
		//NVIC_DisableIRQ(USB0_IRQn);
		pUSB->tx_flags &= ~TX_BUSY;
		//NVIC_EnableIRQ(USB0_IRQn);
		//ToDo:
	}
	return LPC_OK;
}

#if USB_INT_IN
/* USB bulk EP_IN endpoint handler*/
ErrorCode_t IntrIN_Hdlr(USBD_HANDLE_T hUsb, void *data, uint32_t event){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) data;

	if (event == USB_EVT_IN) {
		// check if we have new status to send
		if (pUSB->newStatus) {
			// swap and send status
			pUSB->curStatus = pUSB->newStatus;
			pUSB->newStatus = 0;
			USBD_API->hw->WriteEP(pUSB->hUsb, LUSB_INT_EP, (uint8_t *) &pUSB->curStatus, sizeof(uint32_t));
		}
		else {
			// nothing to send
			pUSB->curStatus = 0;
		}
	}
	return LPC_OK;
}
#endif

#if USB_BULK_OUT
/* USB bulk EP_OUT endpoint handler */
ErrorCode_t BulkOUT_Hdlr(USBD_HANDLE_T hUsb, void *data, uint32_t event){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) data;

	// We received a transfer from the USB host.
	if (event == USB_EVT_OUT) {
		pUSB->rxBuffLen = USBD_API->hw->ReadEP(hUsb, LUSB_OUT_EP, pUSB->pRxBuf);
		pUSB->pRxBuf = 0;
	}
	return LPC_OK;
}
#endif

/* Handler for WCID USB device requests. */
ErrorCode_t WCID_hdlr(USBD_HANDLE_T hUsb, void *data, uint32_t event){
	USB_CORE_CTRL_T *pCtrl = (USB_CORE_CTRL_T *) hUsb;
	ErrorCode_t ret = ERR_USBD_UNHANDLED;

	if (event == USB_EVT_SETUP) {
		switch (pCtrl->SetupPacket.bmRequestType.BM.Type) {
			case REQUEST_STANDARD:
				if ((pCtrl->SetupPacket.bmRequestType.BM.Recipient == REQUEST_TO_DEVICE) &&
					(pCtrl->SetupPacket.bRequest == USB_REQUEST_GET_DESCRIPTOR) &&
					(pCtrl->SetupPacket.wValue.WB.H == USB_STRING_DESCRIPTOR_TYPE) &&
					(pCtrl->SetupPacket.wValue.WB.L == 0x00EE)) {
					pCtrl->EP0Data.pData = (uint8_t *) &WinUSB_String_Descriptor;
					pCtrl->EP0Data.Count = pCtrl->SetupPacket.wLength;
					USBD_API->core->DataInStage(pCtrl);
					ret = LPC_OK;
				}
				break;
		case REQUEST_VENDOR:
			switch (pCtrl->SetupPacket.bRequest) {
				case LUSB_PID:
					if (pCtrl->SetupPacket.wIndex.W == 0x04) {
						pCtrl->EP0Data.pData = (uint8_t *) &WinUSB_CompactID;
						pCtrl->EP0Data.Count = pCtrl->SetupPacket.wLength;
						USBD_API->core->DataInStage(pCtrl);
						ret = LPC_OK;
					}
					if(pCtrl->SetupPacket.wIndex.W == 0x05){
						pCtrl->EP0Data.pData = (uint8_t *) &WinUSB_OS_Feature_Desc;
						pCtrl->EP0Data.Count = pCtrl->SetupPacket.wLength;
						USBD_API->core->DataInStage(pCtrl);
						ret = LPC_OK;
					}
					break;
				case 0x0001: //CoreClock
					pCtrl->EP0Data.pData = (uint8_t *) &SystemCoreClock;
					pCtrl->EP0Data.Count = pCtrl->SetupPacket.wLength;
					USBD_API->core->DataInStage(pCtrl);
					ret = LPC_OK;
					break;
				case 0x0002: //ping
					pCtrl->EP0Data.pData = NULL;
					pCtrl->EP0Data.Count = pCtrl->SetupPacket.wLength;
					USBD_API->core->DataInStage(pCtrl);
					ret = LPC_OK;
					break;
				default:
					USBD_API->core->DataInStage(pCtrl);
					PerformUSB_Vendor(pCtrl->SetupPacket.bRequest, pCtrl->SetupPacket.wValue.W);
					ret = LPC_OK;
					break;
				}
		}
	}
	else if ((event == USB_EVT_OUT) && (pCtrl->SetupPacket.bmRequestType.BM.Type == REQUEST_VENDOR)) {
		if (pCtrl->SetupPacket.bRequest == 0x10) {
			USBD_API->core->StatusInStage(pCtrl);
			ret = LPC_OK;
		}
	}

	return ret;
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Handle interrupt from USB */
void USB_IRQHandler(void){
#ifdef RTOS
//portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
#endif
	USBD_API->hw->ISR(g_lusb.hUsb);
#ifdef RTOS
	//xSemaphoreGiveFromISR( USB_Semaphore, NULL);//, &xHigherPriorityTaskWoken);
	//portEND_SWITCHING_ISR( xHigherPriorityTaskWoken);
#endif
}

/* Initialize USB interface. */
int dev_init(uint32_t memBase, uint32_t memSize){
#ifdef RTOS
	//vSemaphoreCreateBinary(USB_Semaphore);
#endif

    USBD_API_INIT_PARAM_T usb_param;
    USB_CORE_DESCS_T desc;
	ErrorCode_t ret = LPC_OK;

	/* enable clocks */
	Chip_USB_Init();


	/* Init USB API structure */
	g_pUsbApi = (const USBD_API_T *) LPC_ROM_API->pUSBD;

	/* initialize call back structures */
	memset((void *) &usb_param, 0, sizeof(USBD_API_INIT_PARAM_T));
	usb_param.usb_reg_base = LPC_USB0_BASE;
	usb_param.max_num_ep = 5;
	usb_param.mem_base = memBase;
	usb_param.mem_size = memSize;
	usb_param.USB_Reset_Event = ResetEvent;

	/* Set the USB descriptors */
		desc.device_desc = (uint8_t *) &USB_DeviceDescriptor;
		desc.string_desc = (uint8_t *) USB_StringDescriptor;
	#ifdef USE_USB0
		desc.high_speed_desc = USB_HsConfigDescriptor;
		desc.full_speed_desc = USB_FsConfigDescriptor;
		desc.device_qualifier = (uint8_t *) USB_DeviceQualifier;
	#else
		/* Note, to pass USBCV test full-speed only devices should have both
		 * descriptor arrays point to same location and device_qualifier set
		 * to 0.
		 */
		desc.high_speed_desc = (uint8_t *) &USB_FsConfigDescriptor;
		desc.full_speed_desc = (uint8_t *) &USB_FsConfigDescriptor;
		desc.device_qualifier = 0;
	#endif

	/* USB Initialization */
	ret = USBD_API->hw->Init(&g_lusb.hUsb, &desc, &usb_param);
	if (ret == LPC_OK) {
		/* register WCID handler */
		ret = USBD_API->core->RegisterClassHandler(g_lusb.hUsb, WCID_hdlr, &g_lusb);
		if (ret == LPC_OK) {
#if USB_BULK_IN
			ret = USBD_API->core->RegisterEpHandler(g_lusb.hUsb, 3, BulkIN_Hdlr, &g_lusb);
			if (ret == LPC_OK) {
#endif
#if USB_BULK_OUT
				ret = USBD_API->core->RegisterEpHandler(g_lusb.hUsb, 2, BulkOUT_Hdlr, &g_lusb);
				if (ret == LPC_OK) {
#endif
#if USB_INT_IN
					ret = USBD_API->core->RegisterEpHandler(g_lusb.hUsb, 5, IntrIN_Hdlr, &g_lusb);
					if (ret == LPC_OK) {
#endif
						NVIC_EnableIRQ(USB0_IRQn);/*  enable USB interrrupts */
						/* now connect */
						USBD_API->hw->Connect(g_lusb.hUsb, 1);
#if USB_INT_IN
					}
#endif
#if USB_BULK_OUT
				}
#endif
#if USB_BULK_IN
			}
#endif
		}
	}

	return ret;
}

/* Check if dev is connected USB host application. */
bool dev_Connected(void){
	return USB_IsConfigured(g_lusb.hUsb);
}
#if USB_BULK_OUT
/* Queue the read buffer to USB DMA */
ErrorCode_t dev_QueueReadReq(uint8_t *pBuf, uint32_t buf_len){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) &g_lusb;
	ErrorCode_t ret = ERR_FAILED;

	/* Check if a read request is pending */
	if (pUSB->pRxBuf == 0) {
		/* Queue the read request */
		pUSB->pRxBuf = pBuf;
		pUSB->rxBuffLen = buf_len;
		USBD_API->hw->ReadReqEP(pUSB->hUsb, LUSB_OUT_EP, pBuf, buf_len);
		ret = LPC_OK;
	}
	return ret;
}


/* Check if queued read buffer got any data */
int32_t dev_QueueReadDone(void){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) &g_lusb;

	/* A read request is pending */
	if (pUSB->pRxBuf) {
		return -1;
	}
	/* if data received return the length */
	return pUSB->rxBuffLen;
}

/* A blocking read call */
int32_t dev_Read(uint8_t *pBuf, uint32_t buf_len){
	int32_t ret = -1;

	/* Queue read request  */
	if (dev_QueueReadReq(pBuf, buf_len) == LPC_OK) {
		/* wait for Rx to complete */
		while ( (ret = dev_QueueReadDone()) == -1) {
			/* Sleep until next IRQ happens */
			__WFI();
		}
	}

	return ret;
}
#endif

#if USB_BULK_IN
/* Queue the given buffer for transmision to USB host application. */
int32_t dev_QueueSendReq(uint8_t *pBuf, uint32_t buf_len){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) &g_lusb;
	ErrorCode_t ret = 0;

	//return ret = USBD_API->hw->WriteEP(pUSB->hUsb, LUSB_IN_EP, pBuf, buf_len);
	//ToDo::
	/* Check if a read request is pending */
	if ((pUSB->tx_flags & TX_BUSY) == 0) {
		//This flag is set to zero when in the bulk interrupt when no more data is ready to send
		pUSB->tx_flags |= TX_BUSY;
		/* enter critical section */
		//NVIC_DisableIRQ(USB0_IRQn);
		ret = USBD_API->hw->WriteEP(pUSB->hUsb, LUSB_IN_EP, pBuf, buf_len);
		/* exit critical section */
		//NVIC_EnableIRQ(USB0_IRQn);
	}

	return ret;
}

/* Check if queued send is done. */
int32_t dev_QueueSendDone(void){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) &g_lusb;
	/* return remaining length */
	return pUSB->txBuffLen;
}

/* Send the given buffer to USB host application */
ErrorCode_t dev_Send(uint8_t *pBuf, uint32_t buf_len){
	int32_t ret = dev_QueueSendReq(pBuf, buf_len);

	/* Queue read request  */
	if (ret == buf_len) {
		/* wait for Rx to complete */
		while (dev_QueueSendDone() != 0) {
			/* Sleep until next IRQ happens */
			//__WFI();
		}
	}

	return ret;
}
#endif

#if USB_INT_IN
/* Send interrupt signal to USB host application. */
ErrorCode_t dev_SendInterrupt(uint32_t status){
	LUSB_CTRL_T *pUSB = (LUSB_CTRL_T *) &g_lusb;

	// enter critical section
	NVIC_DisableIRQ(USB0_IRQn);
	// update new status
	pUSB->newStatus = status;
	// exit critical section
	NVIC_EnableIRQ(USB0_IRQn);

	// check if we are in middle of sending current status
	if ( pUSB->curStatus == 0) {
		// If not update current status and send
		pUSB->curStatus = pUSB->newStatus;
		pUSB->newStatus = 0;
		USBD_API->hw->WriteEP(pUSB->hUsb, LUSB_INT_EP, (uint8_t *) &pUSB->curStatus, sizeof(uint32_t));
	}

	return LPC_OK;
}
#endif
