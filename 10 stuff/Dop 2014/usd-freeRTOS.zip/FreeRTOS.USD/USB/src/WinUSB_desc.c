/*
 * WinUSB_desc.c
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */

#include "chip.h"

#include "WinUSB_desc.h"
#include "app_usbd_cfg.h"

ALIGNED(4) const OS_STRING WinUSB_String_Descriptor = {
	.bLength = sizeof(OS_STRING),
	.bDescriptorType = USB_STRING_DESCRIPTOR_TYPE,
	.qwSignature = {'M','S','F','T','1','0','0'},
	.bMS_VendorCode = LUSB_PID,
	.bPad = 0
};

ALIGNED(4) const OS_DESC_COMPACTID WinUSB_CompactID = {
	.Header = {
		.dwLength = sizeof(OS_DESC_COMPACTID),
		.bcdVersion = 0x0100,
		.wIndex = 0x004,
		.bCount = 0x01,
		.Reserved = {0}
	},
	.Function0 = {
		.bFirstInterfaceNumber = 0x00,
		.RESERVED = 0x01,
		.compatibleID = "WINUSB",
		.subCompatibleID = {0},
		.Reserved = {0}
	}
};

ALIGNED(4) const EXT_P_OS_Feature_Desc  WinUSB_OS_Feature_Desc = {
	.Header = {
		.Length =  0x0000008E,//0x000000A0, // 132 142 sizeof(EXT_P_OS_Feature_Desc), 			/* Length 246 bytes */
		.bcdVersion = 0x0100, 			/* Version 1.0 */
		.wIndex = 0x0005,				/* This is an extended property OS feature descriptor */
		.wCount = 0x0001,				/* Number of custom property sections */
	},
	.wSize = 0x00000084,				/* Length of this custom property section is 136 bytes */
	.wPropertyDataType = 0x00000001,	/* Property value stores a Unicode string */
	.wPropertyNameLength = 0x0028,		/* Length of the property name string is 42 bytes */
	.bPropertyName = {'D','e','v','i','c','e','I','n','t','e','r','f','a','c','e','G','U','I','D',0},
	.wPropertyDataLength = 0x0000004E,	/* Length of the property value string is 78 + 2 (80) bytes */
	.bPropertyData = {'{','F','7','0','2','4','2','C','7','-','F','B','2','5','-','4','4','3','B',
					  '-','9','E','7','E','-','A','4','2','6','0','F','3','7','3','9','8','2','}',0},
					  /*	.Label = {
		.dwSize = 0x00000030 ,// sizeof(EXT_P_OS_LABEL), 48
		.dwPropertyDataType = 0x00000001,
		.wPropertyNameLength = 0x000C,
		.bPropertyName = {'L','a','b','e','l'},
		.dwPropertyDataLength = 0x00000016, //0x00000028, //  , //18*2 = 36 -> HEX = 26 + 2
		.bPropertyData = {'U','S','D',' ','D','e','v','i','c','e'},//{'U','l','t','r','a','s','o','n','i','c',' ','D','o','p','p','l','e','r'}, //
	},
					  .Icon = {
	.dwSize = sizeof(EXT_P_OS_ICONS),
	.dwPropertyDataType = 0x00000002,
	.wPropertyNameLength = 0x000C,
	.bPropertyName = {'I','c','o','n','s'},
	.dwPropertyDataLength = sizeof(L"%SystemRoot%\\system32\\DDORes.dll,-56"), //0x50, //72
	.bPropertyData =  {'%','S','y','s','t','e','m','R','o','o','t','%','\\','s','y','s','t','e','m','3','2','\\','D','D','O','R','e','s','.','d','l','l',',','-','5','6'},  //'i','m','a','g','e','r','e','s','.','d','l','l',',','-','1','4','5'},
	// \ ^ 0x92
	},
*/
};
