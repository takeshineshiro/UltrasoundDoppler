/*
 * common_desc.c
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */

#include "common_desc.h"

#ifdef CFG_USB


/* extended usb macros*/
#define HID_USAGE_CONSUMER_ACPAN     0x38, 0x02 // 0x0238
#define HID_Usage_2Bytes(x)          0x0a, x

enum USB_HID_LOCAL_CODE
{
  HID_Local_NotSupported = 0,
  HID_Local_Arabic,
  HID_Local_Belgian,
  HID_Local_Canadian_Bilingual,
  HID_Local_Canadian_French,
  HID_Local_Czech_Republic,
  HID_Local_Danish,
  HID_Local_Finnish,
  HID_Local_French,
  HID_Local_German,
  HID_Local_Greek,
  HID_Local_Hebrew,
  HID_Local_Hungary,
  HID_Local_International,
  HID_Local_Italian,
  HID_Local_Japan_Katakana,
  HID_Local_Korean,
  HID_Local_Latin_American,
  HID_Local_Netherlands_Dutch,
  HID_Local_Norwegian,
  HID_Local_Persian_Farsi,
  HID_Local_Poland,
  HID_Local_Portuguese,
  HID_Local_Russia,
  HID_Local_Slovakia,
  HID_Local_Spanish,
  HID_Local_Swedish,
  HID_Local_Swiss_French,
  HID_Local_Swiss_German,
  HID_Local_Switzerland,
  HID_Local_Taiwan,
  HID_Local_Turkish_Q,
  HID_Local_UK,
  HID_Local_US,
  HID_Local_Yugoslavia,
  HID_Local_Turkish_F
};

#ifdef CFG_USB_HID_KEYBOARD
ALIGNED(4) const uint8_t HID_KeyboardReportDescriptor[] = {
  HID_UsagePage  ( HID_USAGE_PAGE_GENERIC     ),
  HID_Usage      ( HID_USAGE_GENERIC_KEYBOARD ),
  HID_Collection ( HID_Application            ),
    HID_UsagePage (HID_USAGE_PAGE_KEYBOARD),
      HID_UsageMin    (224                                     ),
      HID_UsageMax    (231                                     ),
      HID_LogicalMin  ( 0                                      ),
      HID_LogicalMax  ( 1                                      ),

      HID_ReportCount ( 8                                      ), /* 8 bits */
      HID_ReportSize  ( 1                                      ),
      HID_Input       ( HID_Data | HID_Variable | HID_Absolute ), /* maskable modifier key */

      HID_ReportCount ( 1                                      ),
      HID_ReportSize  ( 8                                      ),
      HID_Input       (HID_Constant                            ), /* reserved */

    HID_UsagePage  ( HID_USAGE_PAGE_LED                   ),
      HID_UsageMin    (1                                       ),
      HID_UsageMax    (5                                       ),
      HID_ReportCount (5                                       ),
      HID_ReportSize  (1                                       ),
      HID_Output      ( HID_Data | HID_Variable | HID_Absolute ), /* 5-bit Led report */

      HID_ReportCount ( 1                                      ),
      HID_ReportSize  (3                                       ), /* led padding */
      HID_Output      (HID_Constant                            ),

    HID_UsagePage (HID_USAGE_PAGE_KEYBOARD),
      HID_UsageMin    (0                                   ),
      HID_UsageMax    (101                                 ),
      HID_LogicalMin  (0                                       ),
      HID_LogicalMax  (101                                     ),

      HID_ReportCount (6                                   ),
      HID_ReportSize  (8                                   ),
      HID_Input       (HID_Data | HID_Array | HID_Absolute ), /* keycodes array 6 items */
  HID_EndCollection,
};
#endif

#ifdef CFG_USB_HID_MOUSE
ALIGNED(4) const uint8_t HID_MouseReportDescriptor[] = {
  HID_UsagePage  ( HID_USAGE_PAGE_GENERIC     ),
  HID_Usage      ( HID_USAGE_GENERIC_MOUSE ),
  HID_Collection ( HID_Application            ),
    HID_Usage (HID_USAGE_GENERIC_POINTER),

    HID_Collection ( HID_Physical ),
      HID_UsagePage  ( HID_USAGE_PAGE_BUTTON     ),
        HID_UsageMin    ( 1                                      ), /* FW | BW | MD | RM | LM */
        HID_UsageMax    ( 5                                      ),
        HID_LogicalMin  ( 0                                      ),
        HID_LogicalMax  ( 1                                      ),

        HID_ReportCount ( 5                                      ),
        HID_ReportSize  ( 1                                      ),
        HID_Input       ( HID_Data | HID_Variable | HID_Absolute ),

        HID_ReportCount ( 1                                      ),
        HID_ReportSize  ( 3                                      ),
        HID_Input       (HID_Constant                            ), /* reserved */

      HID_UsagePage  ( HID_USAGE_PAGE_GENERIC ),
        HID_Usage       ( HID_USAGE_GENERIC_X                    ), /* X, Y position */
        HID_Usage       ( HID_USAGE_GENERIC_Y                    ),
        HID_LogicalMin  ( 0x81                                   ), /* -127 */
        HID_LogicalMax  ( 0x7f                                   ), /* 127  */

        HID_ReportCount ( 2                                      ),
        HID_ReportSize  ( 8                                      ), /* X, Y is 8-bit */
        HID_Input       ( HID_Data | HID_Variable | HID_Relative ), /* relative values */

        HID_Usage       ( HID_USAGE_GENERIC_WHEEL                ), /* mouse scroll */
        HID_LogicalMin  ( 0x81                                   ), /* -127 */
        HID_LogicalMax  ( 0x7f                                   ), /* 127  */
        HID_ReportCount ( 1                                      ),
        HID_ReportSize  ( 8                                      ), /* 8-bit value */
        HID_Input       ( HID_Data | HID_Variable | HID_Relative ), /* relative values */

      HID_UsagePage     ( HID_USAGE_PAGE_CONSUMER         ),
        HID_Usage_2Bytes( HID_USAGE_CONSUMER_ACPAN               ), /* mouse scroll */
        HID_LogicalMin  ( 0x81                                   ), /* -127 */
        HID_LogicalMax  ( 0x7f                                   ), /* 127  */
        HID_ReportCount ( 1                                      ),
        HID_ReportSize  ( 8                                      ), /* 8-bit value */
        HID_Input       ( HID_Data | HID_Variable | HID_Relative ), /* relative values */

    HID_EndCollection,

  HID_EndCollection,
};
#endif

#ifdef CFG_USB_HID_GENERIC

#define  HID_GENERIC_USAGEPAGE_VENDOR  0x00
#define  HID_GENERIC_USAGE_COLLECTION  0x01
#define  HID_GENERIC_USAGE_IN          0x02
#define  HID_GENERIC_USAGE_OUT         0x03

ALIGNED(4) const uint8_t HID_GenericReportDescriptor[] = {
    HID_UsagePageVendor (HID_GENERIC_USAGEPAGE_VENDOR ),
    HID_Usage           (HID_GENERIC_USAGE_COLLECTION ),
    HID_Collection      (HID_Application              ),
      HID_Usage       (HID_GENERIC_USAGE_IN                   ),
      HID_LogicalMin  (0x00                                   ),
      HID_LogicalMax  (0xff                                   ),
      HID_ReportSize  (8                                      ),
      HID_ReportCount (CFG_USB_HID_GENERIC_REPORT_SIZE        ),
      HID_Input       (HID_Data | HID_Variable | HID_Absolute ),

      HID_Usage       (HID_GENERIC_USAGE_OUT                   ),
      HID_LogicalMin  (0x00                                    ),
      HID_LogicalMax  (0xff                                    ),
      HID_ReportSize  (8                                       ),
      HID_ReportCount (CFG_USB_HID_GENERIC_REPORT_SIZE         ),
      HID_Output      ( HID_Data | HID_Variable | HID_Absolute ),

    HID_EndCollection,
};
#endif

/* USB Standard Device Descriptor */

ALIGNED(4) const USB_DEVICE_DESCRIPTOR USB_DeviceDescriptor =
{
  .bLength            = USB_DEVICE_DESC_SIZE,
  .bDescriptorType    = USB_DEVICE_DESCRIPTOR_TYPE,
  .bcdUSB             = 0x0200,

  #if IAD_DESC_REQUIRED
  // Multiple Interfaces Using Interface Association Descriptor (IAD)
  .bDeviceClass       = USB_DEVICE_CLASS_IAD,
  .bDeviceSubClass    = USB_DEVICE_SUBCLASS_IAD,
  .bDeviceProtocol    = USB_DEVICE_PROTOCOL_IAD,
  #elif defined CFG_USB_CDC
  .bDeviceClass       = CDC_COMMUNICATION_INTERFACE_CLASS,
  .bDeviceSubClass    = 0x00,
  .bDeviceProtocol    = 0x00,
  #else
  .bDeviceClass       = 0xFF,
  .bDeviceSubClass    = 0x00,
  .bDeviceProtocol    = 0x00,
  #endif

  .bMaxPacketSize0    = USB_MAX_PACKET0,

  .idVendor           = CFG_USB_VENDORID,
  .idProduct          = CFG_USB_PRODUCTID,
  .bcdDevice          = 0x0100,

  .iManufacturer      = 0x01,
  .iProduct           = 0x02,
  .iSerialNumber      = 0x03,

  .bNumConfigurations = 0x01
};
#endif /* CFG_USB */
