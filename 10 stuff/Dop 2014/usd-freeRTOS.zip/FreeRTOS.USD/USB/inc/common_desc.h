/*
 * common_desc.h
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */

#ifndef COMMON_DESC_H_
#define COMMON_DESC_H_

#include "usbd/usbd.h"
#include "Board_Config.h"
#include "app_usbd_cfg.h"

#ifdef CFG_USB
#ifdef USB_WIN
#include "WinUSB_desc.h"
#endif

/* --- RTOS --- */
#ifdef RTOS
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
xSemaphoreHandle USB_Semaphore;
#endif

extern void PerformUSB_Vendor(int8_t cmd, uint16_t Value);

#define TX_CONNECTED   _BIT(8)		/* connection state is for both RX/Tx */
#define TX_REQ         _BIT(1)
#define TX_BUSY        _BIT(0)


/* USB Serial uses the MCUs unique 128-bit chip ID via an IAP call = 32 hex chars */
#define USB_STRING_SERIAL_LEN     32

#define USB_STRING_LEN(n) (2 + ((n)<<1))

typedef PRE_PACK struct POST_PACK _USB_STR_DESCRIPTOR
{
  USB_COMMON_DESCRIPTOR LangID;
  uint16_t strLangID[1];

  USB_COMMON_DESCRIPTOR Manufacturer;
  uint16_t strManufacturer[sizeof(CFG_USB_STRING_MANUFACTURER)-1]; // exclude null-character

  USB_COMMON_DESCRIPTOR Product;
  uint16_t strProduct[sizeof(CFG_USB_STRING_PRODUCT)-1]; // exclude null-character

  USB_COMMON_DESCRIPTOR Serial;
  uint16_t strSerial[USB_STRING_SERIAL_LEN];
} USB_STR_DESCRIPTOR;

// USB Interface Assosication Descriptor
#define  USB_DEVICE_CLASS_IAD        USB_DEVICE_CLASS_MISCELLANEOUS
#define  USB_DEVICE_SUBCLASS_IAD     0x02
#define  USB_DEVICE_PROTOCOL_IAD     0x01

///////////////////////////////////////////////////////////////////////
// Interface Assosication Descriptor if device is CDC + other class
#define IAD_DESC_REQUIRED ( defined(CFG_USB_CDC) && ( defined(CFG_USB_HID) || defined(CFG_USB_MSC) || defined(CFG_USB_CUSTOM_CLASS)) )

#ifndef USB_PRODUCT_ID
// Bitmap: MassStorage | Generic | Mouse | Key | CDC
#define PRODUCTID_BITMAP(interface, n)  ( (INTERFACES_OF_##interface ? 1 : 0) << (n) )
#define USB_PRODUCT_ID                  (0x2000 | ( PRODUCTID_BITMAP(CDC, 0) | PRODUCTID_BITMAP(HID_KEYBOARD, 1) |\
                                         PRODUCTID_BITMAP(HID_MOUSE, 2) | PRODUCTID_BITMAP(HID_GENERIC, 3) |\
                                         PRODUCTID_BITMAP(MSC, 4) | PRODUCTID_BITMAP(CUSTOM, 5) ) )
#endif

typedef struct
{
  USB_CONFIGURATION_DESCRIPTOR                Config;

#ifdef CFG_USB_CUSTOM_CLASS
  USB_INTERFACE_DESCRIPTOR                    Custom_Interface;
  USB_ENDPOINT_DESCRIPTOR                     Custom_BulkIN;
  //USB_ENDPOINT_DESCRIPTOR                     Custom_BulkOUT;
  //USB_ENDPOINT_DESCRIPTOR                     HID_GenericINEndpoint;
#endif

  unsigned char                               ConfigDescTermination;
} USB_FS_CONFIGURATION_DESCRIPTOR;

extern const USB_DEVICE_DESCRIPTOR USB_DeviceDescriptor;
//extern const USB_FS_CONFIGURATION_DESCRIPTOR USB_FsConfigDescriptor;
//extern USB_STR_DESCRIPTOR USB_StringDescriptor;

extern const uint8_t HID_KeyboardReportDescriptor[];
extern const uint8_t HID_MouseReportDescriptor[];
extern const uint8_t HID_GenericReportDescriptor[];


/** USB Default Control Pipe Setup Packet*/
typedef struct _USB_SETUP_PACKET USB_SETUP_PACKET;


/* --- Configs ---*/
typedef struct _LUSB_CTRL_ {
	USBD_HANDLE_T hUsb;
	uint8_t *pRxBuf;
	uint32_t rxBuffLen;
	uint8_t *pTxBuf;
	uint32_t txBuffStart;
	uint32_t txBuffLen;
	uint32_t newStatus;
	uint32_t curStatus;
	volatile uint8_t connected;
	volatile uint16_t tx_flags;
} LUSB_CTRL_T;


extern LUSB_CTRL_T g_lusb;


ErrorCode_t usb_init(void);

#define LUSB_PID                        0x8A
#define LUSB_IN_EP                      0x81
#define LUSB_OUT_EP                     0x01
#define LUSB_INT_EP                     0x82

extern const uint8_t WCID_String_Descriptor[];
extern const uint8_t WCID_CompatID_Descriptor[];

/** @ingroup EXAMPLES_USBDROM_18XX43XX_LUSBK
 * @{
 */

/**
 * @brief	Initialize USB interface.
 * @param	mem_base	: Pointer to memory address which can be used by libusbdev driver
 * @param	mem_size	: Size of the memory passed
 * @return	If found returns the address of requested interface else returns NULL.
 */
extern ErrorCode_t dev_init(uint32_t memBase, uint32_t memSize);

/**
 * @brief	Check if libusbdev is connected USB host application.
 * @return	Returns non-zero value if connected.
 */
extern bool dev_Connected(void);

#if USB_BULK_OUT
/**
 * @brief	Queue the read buffer to USB DMA
 * @param	pBuf	: Pointer to buffer where read data should be copied
 * @param	buf_len	: Length of the buffer passed
 * @return	Returns LPC_OK on success.
 */
extern ErrorCode_t dev_QueueReadReq(uint8_t *pBuf, uint32_t buf_len);

/**
 * @brief	Check if queued read buffer got any data
 * @return	Returns length of data received. Returns -1 if read is still pending.
 * @note	Since on USB, zero length packets are transferred -1 is used for
 *			Rx pending indication.
 */
extern int32_t dev_QueueReadDone (void);

/**
 * @brief	A blocking read call
 * @param	pBuf	: Pointer to buffer where read data should be copied
 * @param	buf_len	: Length of the buffer passed
 * @return	Return number of bytes read. Returns -1 if previous read is pending.
 */
extern int32_t dev_Read(uint8_t *pBuf, uint32_t buf_len);
#endif

#if USB_BULK_IN
/**
 * @brief	Queue the given buffer for transmission to USB host application.
 * @param	pBuf	: Pointer to buffer to be written
 * @param	buf_len	: Length of the buffer passed
 * @return	Returns LPC_OK on success.
 */
extern int32_t dev_QueueSendReq(uint8_t *pBuf, uint32_t buf_len);

/**
 * @brief	Check if queued send is done.
 * @return	Returns length of remaining data to be sent.
 *			0 indicates transfer done.
 */
extern int32_t dev_QueueSendDone (void);

/**
 * @brief	Send the given buffer to USB host application.
 * @param	pBuf	: Pointer to buffer to be written
 * @param	buf_len	: Length of the buffer passed
 * @return	Returns LPC_OK on success.
 * @note	This is a BLOCKING call until Tx is done.
 */
extern ErrorCode_t dev_Send(uint8_t *pBuf, uint32_t buf_len);
#endif

#if USB_INT_IN
/**
 * @brief	Send interrupt signal to USB host application.
 * @param	status	: A 32 bit status sent to host at next interrupt
 * @return	Returns LPC_OK on success.
 * @note	USB host polls our device at interval specified
 *			by bInterval field of LUSB_INT_EP endpoint's descriptor.
 *			This routine sends the specified status on next polling opportunity.
 *			Use the routine to tell host we have data to send. So that it can
 *			start putting IN tokens.

 */
extern ErrorCode_t dev_SendInterrupt(uint32_t status);
#endif

/**
 * @}
 */

#ifdef CFG_USB_CDC
  #define INTERFACES_OF_CDC                 (2)
#else
  #define INTERFACES_OF_CDC                 (0)
#endif

#ifdef CFG_USB_HID_KEYBOARD
  #define INTERFACES_OF_HID_KEYBOARD        (1)
#else
  #define INTERFACES_OF_HID_KEYBOARD        (0)
#endif

#ifdef CFG_USB_HID_MOUSE
  #define INTERFACES_OF_HID_MOUSE           (1)
#else
  #define INTERFACES_OF_HID_MOUSE           (0)
#endif


#ifdef CFG_USB_HID_GENERIC
  #define INTERFACES_OF_HID_GENERIC         (1)
#else
  #define INTERFACES_OF_HID_GENERIC         (0)
#endif

#ifdef CFG_USB_MSC
  #define INTERFACES_OF_MSC                 (1)
#else
  #define INTERFACES_OF_MSC                 (0)
#endif

#ifdef CFG_USB_CUSTOM_CLASS
  #define INTERFACES_OF_CUSTOM              (1)
#else
  #define INTERFACES_OF_CUSTOM              (0)
#endif

#define INTERFACE_INDEX_CDC                 (0)
#define INTERFACE_INDEX_HID_KEYBOARD        (INTERFACE_INDEX_CDC          + INTERFACES_OF_CDC          )
#define INTERFACE_INDEX_HID_MOUSE           (INTERFACE_INDEX_HID_KEYBOARD + INTERFACES_OF_HID_KEYBOARD )
#define INTERFACE_INDEX_HID_GENERIC         (INTERFACE_INDEX_HID_MOUSE    + INTERFACES_OF_HID_MOUSE    )
#define INTERFACE_INDEX_MSC                 (INTERFACE_INDEX_HID_GENERIC  + INTERFACES_OF_HID_GENERIC  )
#define INTERFACE_INDEX_CUSTOM              (INTERFACE_INDEX_MSC          + INTERFACES_OF_MSC          )

#define TOTAL_INTEFACES                     (INTERFACES_OF_CDC + INTERFACES_OF_HID_KEYBOARD + INTERFACES_OF_HID_MOUSE +\
    INTERFACES_OF_HID_GENERIC + INTERFACES_OF_MSC + INTERFACES_OF_CUSTOM)

// Number of Endpoint IN used by CDC, HID is equal to the number of its interface, here we used INTERFACES_OF_CLASS as EP_IN_USED_BY_CLASS
#define  CDC_NUMBER_OF_EP_IN                (INTERFACES_OF_CDC)
#define  HID_KEYBOARD_NUMBER_OF_EP_IN       (INTERFACES_OF_HID_KEYBOARD)
#define  HID_MOUSE_NUMBER_OF_EP_IN          (INTERFACES_OF_HID_MOUSE)
#define  HID_GENERIC_NUMBER_OF_EP_IN        (INTERFACES_OF_HID_GENERIC)
#define  MSC_NUMBER_OF_EP_IN                (INTERFACES_OF_MSC)
#define  CUSTOM_NUMBER_OF_EP_IN             (INTERFACES_OF_CUSTOM)

#define  EP_IN_TOTAL                        (CDC_NUMBER_OF_EP_IN + HID_KEYBOARD_NUMBER_OF_EP_IN + HID_MOUSE_NUMBER_OF_EP_IN+\
    HID_GENERIC_NUMBER_OF_EP_IN + MSC_NUMBER_OF_EP_IN + CUSTOM_NUMBER_OF_EP_IN)

/* CDC Endpoint Address */
#define  CDC_NOTIFICATION_EP                (USB_ENDPOINT_IN(1))
#define  CDC_DATA_EP_IN                     (USB_ENDPOINT_IN(2))
#define  CDC_DATA_EP_OUT                    (USB_ENDPOINT_OUT(1))
#define  CDC_NOTIFICATION_EP_MAXPACKETSIZE  (8)
#define  CDC_DATA_EP_MAXPACKET_SIZE         (16)

/*       HID                                In/Out                Endpoint  Address  */
#define  HID_KEYBOARD_EP_IN                 (CDC_NOTIFICATION_EP  + CDC_NUMBER_OF_EP_IN)
#define  HID_MOUSE_EP_IN                    (HID_KEYBOARD_EP_IN   + HID_KEYBOARD_NUMBER_OF_EP_IN)
#define  HID_GENERIC_EP_IN                  (HID_MOUSE_EP_IN      + HID_MOUSE_NUMBER_OF_EP_IN)
#define  HID_GENERIC_EP_OUT                 (USB_ENDPOINT_OUT(2))

//       MSC                                Enpoint               Address
#define  MSC_EP_IN                          (HID_GENERIC_EP_IN    + HID_GENERIC_NUMBER_OF_EP_IN)
#define  MSC_EP_OUT                         (USB_ENDPOINT_OUT(3))

// CUSTOM CLASS
#define  CUSTOM_EP_IN                       (MSC_EP_IN + MSC_NUMBER_OF_EP_IN)
#define  CUSTOM_EP_OUT                      (USB_ENDPOINT_OUT(4))

#if (EP_IN_TOTAL > 4)
  #error lpc11uxx and lpc13uxx only has up to 4 IN endpoints
#endif

#endif /* CFG_USB */

#endif /* COMMON_DESC_H_ */
