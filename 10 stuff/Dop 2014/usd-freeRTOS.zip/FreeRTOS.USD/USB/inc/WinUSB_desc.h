/*
 * WinUSB_desc.h
 *
 *  Created on: 10.06.2014
 *      Author: Andreas
 */

#ifndef WINUSB_DESC_H_
#define WINUSB_DESC_H_

#include "usbd/usbd.h"
#include "lpc_types.h"


/* WCID USB: Microsoft String Descriptor */
typedef PRE_PACK struct POST_PACK _OS_STRING{
	uint8_t bLength;
	uint8_t bDescriptorType;
	uint16_t qwSignature[7];
	uint8_t bMS_VendorCode;
	uint8_t bPad;
} OS_STRING;



// Extended Properties OS Feature Descriptor Header
typedef PRE_PACK struct POST_PACK _OS_DESC_COMPACTID_H{
	uint32_t dwLength;
	uint16_t bcdVersion;
	uint16_t wIndex;
	uint8_t bCount;
	uint8_t Reserved[7];
} OS_DESC_COMPACTID_H;

typedef PRE_PACK struct POST_PACK _OS_DESC_COMPACTID_F{
	uint8_t bFirstInterfaceNumber;
	uint8_t RESERVED;
	uint8_t compatibleID[8];
	uint8_t subCompatibleID[8];
	uint8_t Reserved[6];
}OS_DESC_COMPACTID_F;

typedef PRE_PACK struct POST_PACK _OS_DESC_COMPACTID{
	OS_DESC_COMPACTID_H Header;
	OS_DESC_COMPACTID_F Function0;
} OS_DESC_COMPACTID;

// Extended Properties OS Feature Descriptor Header
typedef PRE_PACK struct POST_PACK _EXT_P_OS_FD_H{
	uint32_t Length;
	uint16_t bcdVersion;
	uint16_t wIndex;
	uint16_t wCount;
} EXT_P_OS_HEADER;

/*
// Extended Properties OS Feature Descriptor Icons
typedef PRE_PACK struct POST_PACK _EXT_P_OS_FD_ICONS{
	uint32_t dwSize; 				// 104 Bytes
	uint32_t dwPropertyDataType;
	uint16_t wPropertyNameLength; 	// 12 Bytes
	uint16_t bPropertyName[6];
	uint32_t dwPropertyDataLength; 	// 78 Bytes
	uint16_t bPropertyData[sizeof(L"%SystemRoot%\\system32\\DDORes.dll,-56")];		// 38 + Terminate
} EXT_P_OS_ICONS;

// Extended Properties OS Feature Descriptor Label
typedef PRE_PACK struct POST_PACK _EXT_P_OS_FD_LABEL{
	uint32_t dwSize; 				// 48 Bytes
	uint32_t dwPropertyDataType;
	uint16_t wPropertyNameLength; 	// 12 Bytes
	uint16_t bPropertyName[6];
	uint32_t dwPropertyDataLength; 	// 22 Bytes
	uint16_t bPropertyData[10];		// 10 + Terminate
} EXT_P_OS_LABEL;*/

// Extended Properties OS Feature Descriptor Property
typedef PRE_PACK struct POST_PACK _EXT_P_OS_FD_INTERFACEGUID{
	EXT_P_OS_HEADER Header;
	uint32_t wSize;
	uint32_t wPropertyDataType;
	uint16_t wPropertyNameLength;
	uint16_t bPropertyName[20];
	uint32_t wPropertyDataLength;
	uint16_t bPropertyData[39];
	//EXT_P_OS_ICONS Icon;
	//EXT_P_OS_LABEL Label;
} EXT_P_OS_Feature_Desc;

extern const OS_STRING WinUSB_String_Descriptor;
/* WCID USB: Microsoft Compatible ID Feature Descriptor */
extern const OS_DESC_COMPACTID WinUSB_CompactID;
extern const EXT_P_OS_Feature_Desc  WinUSB_OS_Feature_Desc;

#endif /* WINUSB_DESC_H_ */
